import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vex-modal-asignacion-equipo',
  templateUrl: './modal-asignacion-equipo.component.html',
  styleUrls: ['./modal-asignacion-equipo.component.scss']
})
export class ModalAsignacionEquipoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
